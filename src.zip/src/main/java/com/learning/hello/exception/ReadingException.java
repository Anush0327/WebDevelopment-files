package com.learning.hello.exception;

public class ReadingException extends Exception{
	private static final long serialVersionUID = 1L;

	public ReadingException(String message) {
		super(message);
	}
}